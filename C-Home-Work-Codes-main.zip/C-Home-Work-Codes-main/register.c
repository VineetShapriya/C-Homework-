#include<stdio.h>
void dheeraj();
int x=4;
void main()
{
   dheeraj();
   dheeraj();
   dheeraj();
}
void dheeraj()
{
    printf("%d\n",x);
    x=x+5;

    
}