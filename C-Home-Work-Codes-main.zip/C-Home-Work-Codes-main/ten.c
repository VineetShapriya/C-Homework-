#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
   (a>10 && a<100)?printf("I am learning C programming"):printf("I am not learning C programming");
    return 0;
}