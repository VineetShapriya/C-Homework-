#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    (a%5==0)?printf("It is multiple of 5"):printf("It is not multiple of 5");
    return 0;

}