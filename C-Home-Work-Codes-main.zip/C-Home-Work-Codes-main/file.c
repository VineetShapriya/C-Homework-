#include<stdio.h>
int main(){
    printf("\t\t\t\t\t\t\t\t\t\tRaghav\n");
    printf("\t\t\t\t\t\t\t\t\tRaghav\n");
    printf("\t\t\t\t\t\t\tRaghav\n");
    printf("\t\t\t\t\t\tRaghav\n");
    printf("\t\t\t\t\tRaghav\n");
    printf("\t\t\t\tRaghav\n");
    printf("\t\t\tRaghav\n");
    printf("\t\tRaghav\n");
    printf("\tRaghav\n");
    printf("Raghav");
}