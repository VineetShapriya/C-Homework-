//Write a program to print 1 to 15 by using for loop
#include<stdio.h>
int main()
{
    int i;
    for(i=1;i<=15;i++)
    {
        printf(" %d\n",i);
    }
    return 0;

}
