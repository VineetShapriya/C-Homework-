//WAP to count the number of students having age <25 and weight <50 kg out of five
//Age  Weight
//23   51
//26   50
//24   48
//24   49
//25   50
#include<stdio.h>
int main()
{
    int age,weight,x;
    printf("Enter the number of students\n");
    scanf("%d",&x);


}