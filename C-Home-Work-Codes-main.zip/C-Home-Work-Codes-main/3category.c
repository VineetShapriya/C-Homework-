#include<stdio.h>
void main()
{
    int add();
    int c=add();
    printf("sum=%d",c);
}
int add()
{
    int a,b,z;
    printf("enter two numbers: ");
    scanf("%d%d",&a,&b);
    z=a+b;
    return z;
}