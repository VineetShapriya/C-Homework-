
// Sum of array of the elements.
#include<stdio.h>
int main()
{
    int a[5]={1,2,3,4,5};
    int x=0;
    for(int i=0;i<=4;i++)
    {
        x+=a[1];
    
    printf("%d\n",x);
    }

    
    
     return 0;
}
