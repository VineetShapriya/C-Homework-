#include<stdio.h>
int main(){
    int array[5]= {1,2,3,4,5};

    for(int i = array[0];i<=array[4];i++){
        printf("%d\n",i);
    }
}