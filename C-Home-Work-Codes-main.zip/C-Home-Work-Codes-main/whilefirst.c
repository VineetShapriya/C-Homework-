#include<stdio.h>
int main(){
    int x,i=1;

    printf("ENter the number of times : ");
    scanf("%d",&x);

    while(i<=x){
        printf("I am learning c programing \n");
        i++;
    }
}